$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/main/java/Features/twitterAutomation.feature");
formatter.feature({
  "line": 1,
  "name": "QA automation solution for below requirements",
  "description": "",
  "id": "qa-automation-solution-for-below-requirements",
  "keyword": "Feature"
});
formatter.before({
  "duration": 275800,
  "status": "passed"
});
formatter.scenario({
  "line": 3,
  "name": "QA automation solution for Twitter Automation using BDD and Selenium",
  "description": "",
  "id": "qa-automation-solution-for-below-requirements;qa-automation-solution-for-twitter-automation-using-bdd-and-selenium",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "user opens twitter Login Page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "user enters username and password and clicks on login button",
  "rows": [
    {
      "cells": [
        "username",
        "password",
        "accname"
      ],
      "line": 8
    },
    {
      "cells": [
        "qafreelance5@gmail.com",
        "Freelance@108",
        "automate_qa"
      ],
      "line": 9
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "Navigate profile page of logged user and upload a profile picture",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "user Update BIO field in profile section as Test Automation user",
  "keyword": "Then "
});
formatter.step({
  "line": 15,
  "name": "user Update Location field in profile section as Houston, Texas",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "user Update Website field in profile section as twitter.com",
  "keyword": "When "
});
formatter.step({
  "line": 19,
  "name": "user Fetch BIO field ,location and website and check if the submit values got updated on the profile page",
  "rows": [
    {
      "cells": [
        "UserBio",
        "UserLoc",
        "UserWebsite"
      ],
      "line": 20
    },
    {
      "cells": [
        "Test Automation user",
        "Houston, Texas",
        "twitter.com"
      ],
      "line": 21
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 23,
  "name": "user Opens the twitter page of The Times of India and retrieve the tweets that were published in last 2 hrs",
  "keyword": "Then "
});
formatter.step({
  "line": 25,
  "name": "Close the browser",
  "keyword": "Then "
});
formatter.match({
  "location": "twitterStepDefinition.user_opens_twitter_login_page()"
});
formatter.result({
  "duration": 12604561800,
  "status": "passed"
});
formatter.match({
  "location": "twitterStepDefinition.user_enters_username_and_password(DataTable)"
});
formatter.result({
  "duration": 56543759100,
  "status": "passed"
});
formatter.match({
  "location": "twitterStepDefinition.user_clicks_on_login_button()"
});
formatter.result({
  "duration": 13132890000,
  "status": "passed"
});
formatter.match({
  "location": "twitterStepDefinition.user_enters_bio_on_profile_page()"
});
formatter.result({
  "duration": 1036629300,
  "status": "passed"
});
formatter.match({
  "location": "twitterStepDefinition.user_enters_Location_on_profile_page()"
});
formatter.result({
  "duration": 570809100,
  "status": "passed"
});
formatter.match({
  "location": "twitterStepDefinition.user_enters_Website_on_profile_page()"
});
formatter.result({
  "duration": 774632000,
  "status": "passed"
});
formatter.match({
  "location": "twitterStepDefinition.fetch_and_veify_user_details(DataTable)"
});
formatter.result({
  "duration": 6531658800,
  "status": "passed"
});
formatter.match({
  "location": "twitterStepDefinition.user_opens_TOI_Website()"
});
formatter.result({
  "duration": 32000,
  "status": "passed"
});
formatter.match({
  "location": "twitterStepDefinition.close_the_browser()"
});
formatter.result({
  "duration": 5919669600,
  "status": "passed"
});
formatter.after({
  "duration": 203600,
  "status": "passed"
});
});