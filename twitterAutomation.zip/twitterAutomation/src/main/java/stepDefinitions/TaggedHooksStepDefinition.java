package stepDefinitions;

import cucumber.api.java.After;
import cucumber.api.java.Before;

public class TaggedHooksStepDefinition {
	//public static WebDriver driver;

	
	@Before(order=0)
	public void setUP(){
		System.out.println("*************** TESTS STARTS **************");
//		System.setProperty(ChromeDriverService.CHROME_DRIVER_SILENT_OUTPUT_PROPERTY, "true");
//		WebDriverManager.chromedriver().setup();
//		driver = new ChromeDriver();
		
	}

	@After(order=0)
	public void tearDown(){
		System.out.println("*************** END **************");
	}
	
}
