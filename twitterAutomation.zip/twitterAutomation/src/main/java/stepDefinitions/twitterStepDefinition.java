package stepDefinitions;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class twitterStepDefinition {
	WebDriver driver;

	@Given("^user opens twitter Login Page$")
	public void user_opens_twitter_login_page() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "resources/chromedriver.exe");

		driver = new ChromeDriver();
		driver.get("https://twitter.com/");
		driver.manage().window().maximize();
		Thread.sleep(5000);
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals("Twitter. It’s what’s happening / Twitter", title);

	}

	@When("^user enters username and password and clicks on login button$")
	public void user_enters_username_and_password(DataTable credentials) throws InterruptedException {
		Thread.sleep(3000);
		WebElement siginBtn = driver.findElement(By.xpath("//span[text()='Sign in']/.."));
		siginBtn.click();
		Thread.sleep(10000);
		List<List<String>> data = credentials.raw();
		driver.switchTo().activeElement();
		Thread.sleep(6000);
		driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-mk0yit r-1f1sjgu r-13qz1uu']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@autocomplete='username']")).sendKeys(data.get(1).get(0));
		Thread.sleep(6000);
		WebElement nextBtn = driver.findElement(By.xpath("//span[text()='Next']/.."));
		nextBtn.click();
		Thread.sleep(6000);
		if (driver.findElement(By.xpath("//span[text()='Enter your phone number or username']")).isDisplayed()) {
			driver.findElement(By.xpath("//input[@data-testid='ocfEnterTextTextInput']")).click();
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@data-testid='ocfEnterTextTextInput']")).sendKeys(data.get(1).get(2));
			Thread.sleep(3000);
			driver.findElement(By.xpath("//span[text()='Next']/..")).click();
			Thread.sleep(5000);
		} else {
			System.out.println("No Verifiaction");
		}
		driver.switchTo().activeElement();
		Thread.sleep(6000);
		System.out.println("it h");
		// driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-mk0yit r-1f1sjgu
		// r-13qz1uu']/../../../../..")).sendKeys(data.get(1).get(2));

		driver.findElement(By.xpath("//input[@autocomplete='current-password']")).sendKeys(data.get(1).get(1));
		Thread.sleep(3000);
		WebElement loginBtn = driver.findElement(By.xpath("//span[text()='Log in']/../.."));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", loginBtn);

	}

	@When("^Navigate profile page of logged user and upload a profile picture$")
	public void user_clicks_on_login_button() throws Throwable {
		// Click Profile
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement Profile;
		Profile = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(normalize-space(),'Profile')]")));
		Profile.click();

		WebElement EditProfile;
		EditProfile = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Edit profile')]")));
		EditProfile.click();
		Thread.sleep(2000);
		// Upload image
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].setAttribute('style', arguments[1])",
				driver.findElement(By.xpath("/descendant::input[@type='file'][1]")), "0");
		jse.executeScript("arguments[0].setAttribute('class', arguments[1])",
				driver.findElement(By.xpath("/descendant::input[@type='file'][1]/../../div[2]")), "a");
		driver.findElement(By.xpath("//input[@type='file']")).sendKeys(
				"C:\\Users\\admin\\Downloads\\TwitterAutomationSeleniumBDDCucumber-main\\resources\\Image\\Automate-Devops.jpg");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(text(),'Apply')]")).click();
		Thread.sleep(6000);
	}

	@When("^user Update BIO field in profile section as Test Automation user$")
	public void user_enters_bio_on_profile_page() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		// BIO
		WebElement TextBio;
		TextBio = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//textarea[@name='description']")));
		TextBio.click();
		TextBio.sendKeys(Keys.CONTROL + "A" + Keys.BACK_SPACE);
		TextBio.sendKeys("Test Automation user");
	}

	@When("^user Update Location field in profile section as Houston, Texas$")
	public void user_enters_Location_on_profile_page() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement Location;
		Location = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='location']")));
		Location.click();
		Location.sendKeys(Keys.CONTROL + "A" + Keys.BACK_SPACE);
		Location.sendKeys("Houston, Texas");
	}

	@When("^user Update Website field in profile section as twitter.com$")
	public void user_enters_Website_on_profile_page() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement Website;
		Website = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='url']")));
		Website.click();
		Website.sendKeys(Keys.CONTROL + "A" + Keys.BACK_SPACE);
		Website.sendKeys("https://twitter.com");

		driver.findElement(By.xpath("//span[contains(text(),'Save')]")).click();

	}

	@Then("^user Fetch BIO field ,location and website and check if the submit values got updated on the profile page$")
	public void fetch_and_veify_user_details(DataTable userdata) throws InterruptedException {
		List<List<String>> data = userdata.raw();
		driver.navigate().refresh();
		Thread.sleep(6000);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement UserBioelem;
		UserBioelem = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@data-testid='UserDescription']/span")));
		String UserBio = UserBioelem.getText();
		System.out.println("UserBio ::" + UserBio);
		String UserLoc = driver.findElement(By.xpath("//span[@data-testid='UserLocation']")).getText();
		System.out.println("UserLoc ::" + UserLoc);
		String UserWebsite = driver.findElement(By.xpath("//a[@data-testid='UserUrl']/span")).getText();
		System.out.println("UserWebsite ::" + UserWebsite);
		Assert.assertEquals(data.get(1).get(0), UserBio);
		Assert.assertEquals(data.get(1).get(1), UserLoc);
		Assert.assertEquals(data.get(1).get(2), UserWebsite);
	}

	@Then("^user Opens the twitter page of The Times of India and retrieve the tweets that were published in last 2 hrs$")
	public void user_opens_TOI_Website() {
		
	}

	@Then("^Close the browser$")
	public void close_the_browser() throws Throwable {
		Thread.sleep(5000);
		driver.close();
		driver.quit();
	}

}
